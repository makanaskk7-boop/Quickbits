# QuickBits – AI Health Coach

## Run locally
1. Install Node 18+.
2. Get an API key at console.anthropic.com.
3. `ANTHROPIC_API_KEY=your-key node server.js`
4. Open http://localhost:3000

## Deploy (free/cheap)
Push this folder to GitHub, then deploy on Render, Railway or Fly.io as a Node web service.
Start command: `npm start`. Add `ANTHROPIC_API_KEY` as an environment variable.
Never put the key in public/index.html.

## Next steps to earn money
- Add Stripe Checkout for QuickBits Plus ($7/mo) and raise DAILY_LIMIT for paid users.
- Add user accounts (Supabase/Clerk) so limits follow the user, not the IP.
- Add a privacy policy and keep the "not medical advice" notice.
