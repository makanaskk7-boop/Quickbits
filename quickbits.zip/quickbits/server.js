// QuickBits server: zero dependencies, Node 18+.
const http = require("http"), fs = require("fs"), path = require("path");
const KEY = process.env.ANTHROPIC_API_KEY, PORT = process.env.PORT || 3000;
const MODEL = process.env.MODEL || "claude-sonnet-4-6";
const DAILY_LIMIT = +(process.env.DAILY_LIMIT || 20); // free messages per IP/day
if (!KEY) { console.error("Set ANTHROPIC_API_KEY (see .env.example)"); process.exit(1); }

const SYS = "You are QuickBits, a warm, practical wellness coach. Give evidence-based, specific, small-step advice on sleep, movement, nutrition, stress and habits. Keep replies under 150 words, short lines, no markdown headers. Never diagnose or recommend medication or extreme diets. If the user mentions serious symptoms, self-harm, or an eating disorder, respond with care and urge them to contact a professional or emergency services. End with one simple next step.";
const usage = new Map(); // ip -> {day, n}
const today = () => new Date().toISOString().slice(0, 10);
function allowed(ip) {
  const u = usage.get(ip); const d = today();
  if (!u || u.day !== d) { usage.set(ip, { day: d, n: 1 }); return true; }
  return ++u.n <= DAILY_LIMIT;
}
const send = (res, code, obj) => { res.writeHead(code, { "Content-Type": "application/json" }); res.end(JSON.stringify(obj)); };

async function claude(messages, system) {
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({ model: MODEL, max_tokens: 400, system, messages }),
  });
  const j = await r.json();
  if (!r.ok) throw new Error(j.error?.message || "AI error");
  return j.content.filter(c => c.type === "text").map(c => c.text).join("");
}

http.createServer((req, res) => {
  if (req.method === "POST" && req.url === "/api/chat") {
    let raw = ""; req.on("data", c => { raw += c; if (raw.length > 20000) req.destroy(); });
    req.on("end", async () => {
      try {
        const ip = req.headers["x-forwarded-for"]?.split(",")[0] || req.socket.remoteAddress;
        if (!allowed(ip)) return send(res, 429, { error: "Daily free limit reached. Upgrade to QuickBits Plus for unlimited coaching." });
        const { messages, tip, profile = {} } = JSON.parse(raw);
        const ctx = `${SYS}\nUser goal: ${String(profile.goal).slice(0, 40)}. Activity level: ${String(profile.activity).slice(0, 40)}.`;
        const msgs = tip
          ? [{ role: "user", content: "Give ONE tiny, science-backed health tip (max 35 words) for me. Be fresh and specific. Plain text." }]
          : (messages || []).slice(-10).map(m => ({ role: m.role === "assistant" ? "assistant" : "user", content: String(m.content).slice(0, 2000) }));
        send(res, 200, { text: await claude(msgs, ctx) });
      } catch (e) { send(res, 500, { error: "Something went wrong. Please try again." }); console.error(e.message); }
    });
    return;
  }
  const file = path.join(__dirname, "public", req.url === "/" ? "index.html" : path.normalize(req.url).replace(/^(\.\.[/\\])+/, ""));
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    res.writeHead(200, { "Content-Type": file.endsWith(".html") ? "text/html" : "application/octet-stream" });
    res.end(data);
  });
}).listen(PORT, () => console.log(`QuickBits running on http://localhost:${PORT}`));
